# Vuetify Parallax Theme FREE

### Before You Start...

This boilerplate is targeted at beginners who want to start exploring Vuetify without the distraction of a complicated development environment.

For advanced features such as asset compilation, hot-reload, lint-on-save, unit testing, and CSS extraction, we recommend that more experienced developers use one of the installation processes outlined within the [Vuetify Documentation](https://vuetifyjs.com/getting-started/quick-start).

## Usage

Simply open up the `index.html` file. Keep in mind, any changes you made will only reflect once you've refreshed your browser.
